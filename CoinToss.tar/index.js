// Write your code here
import {Component} from 'react'

import './index.css'

const HEADS_IMAGE = 'https://assets.ccbp.in/frontend/react-js/heads-img.png'

const TAILS_IMAGE = 'https://assets.ccbp.in/frontend/react-js/tails-img.png'

class CoinToss extends Component {
  state = {Heads: 0, Tails: 0, tossResultsImage: HEADS_IMAGE}

  changeImageAndCount = () => {
    const {Heads, Tails} = this.state
    const toss = Math.floor(Math.random() * 2)
    let tossImage = ''
    let latestHeadsCount = Heads
    let latestTailsCount = Tails

    if (toss === 0) {
      tossImage = HEADS_IMAGE
      latestHeadsCount += 1
    } else {
      tossImage = TAILS_IMAGE
      latestTailsCount += 1
    }
    this.setState({
      tossResultsImage: tossImage,
      Heads: latestHeadsCount,
      Tails: latestTailsCount,
    })
  }

  render() {
    const {Heads, Tails, tossResultsImage} = this.state
    const totalCount = Heads + Tails
    return (
      <div className="bg-container">
        <div className="Coin-container">
          <h1 className="heading">Coin Toss Game</h1>
          <p className="sub-head">Heads (or) Tails</p>
          <div>
            <img
              src={tossResultsImage}
              alt="toss result"
              className="head-image"
            />
            <div>
              <button
                type="button"
                className="button"
                onClick={this.changeImageAndCount}
              >
                Toss Coin
              </button>
              <div className="count-container">
                <p className="count">Total: {totalCount}</p>
                <p className="count">Heads: {Heads}</p>
                <p className="count">Tails: {Tails}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default CoinToss
